import { MetadataRoute } from 'next';
import site from '@/data/site.json';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: '*',
      allow: '/'
    },
    sitemap: `${site.url}/sitemap.xml`
  };
}
