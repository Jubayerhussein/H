import type { Metadata } from 'next';
import { Space_Grotesk, Inter, JetBrains_Mono } from 'next/font/google';
import './globals.css';
import CustomCursor from '@/components/CustomCursor';
import PageLoader from '@/components/PageLoader';
import site from '@/data/site.json';

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
  weight: ['500', '600', '700']
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  weight: ['400', '500', '600']
});

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains',
  weight: ['400', '500']
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: `${site.brand} — ${site.roles.join(', ')}`,
  description: site.tagline,
  keywords: ['Web3 Ambassador', 'Crypto Content Creator', 'Community Builder', 'Web3 Researcher', '0xZozo'],
  authors: [{ name: site.brand }],
  openGraph: {
    type: 'profile',
    title: `${site.brand} — ${site.roles.join(', ')}`,
    description: site.tagline,
    url: site.url,
    siteName: site.brand,
    images: [{ url: '/og-image.png', width: 1200, height: 630 }]
  },
  twitter: {
    card: 'summary_large_image',
    title: `${site.brand} — ${site.roles.join(', ')}`,
    description: site.tagline,
    images: ['/og-image.png']
  },
  icons: {
    icon: '/favicon.svg'
  },
  alternates: {
    canonical: site.url
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Person',
    name: '0xZozo',
    url: site.url,
    jobTitle: site.roles.join(', '),
    description: site.tagline,
    email: site.email,
    sameAs: []
  };

  return (
    <html lang="en" className={`${spaceGrotesk.variable} ${inter.variable} ${jetbrains.variable}`}>
      <body className="bg-void font-body antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <div className="noise" />
        <PageLoader />
        <CustomCursor />
        {children}
      </body>
    </html>
  );
}
