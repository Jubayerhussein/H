'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Reveal from '@/components/Reveal';
import posts from '@/data/blogPosts.json';

const categories = ['All', 'Web3', 'AI', 'Crypto', 'Tutorials', 'Research'];

export default function BlogPage() {
  const [active, setActive] = useState('All');
  const filtered =
    active === 'All' ? posts : posts.filter((p) => p.category === active);

  return (
    <main className="relative min-h-screen bg-void">
      <Navbar />
      <section className="px-5 pb-24 pt-32 sm:px-8">
        <div className="mx-auto max-w-5xl">
          <Link
            href="/#blog"
            className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-mist hover:text-bone"
          >
            <ArrowLeft size={14} />
            Back home
          </Link>

          <h1 className="mt-6 font-display text-3xl sm:text-5xl font-medium text-bone">
            The <span className="grad-text">Blog</span>
          </h1>

          <div className="mt-8 flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setActive(c)}
                className={`rounded-full border px-4 py-2 font-mono text-xs uppercase tracking-widest transition-colors ${
                  active === c
                    ? 'border-signal bg-signal/10 text-signal-soft'
                    : 'border-white/10 text-mist hover:text-bone'
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2">
            {filtered.map((p, i) => (
              <Reveal key={p.id} delay={i * 0.04}>
                <article id={p.slug} className="glass glass-hover h-full rounded-2xl p-6">
                  <span className="rounded-full border border-white/10 px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-pulse">
                    {p.category}
                  </span>
                  <h2 className="mt-4 font-display text-lg leading-snug text-bone">
                    {p.title}
                  </h2>
                  <p className="mt-2 text-sm leading-relaxed text-mist">{p.excerpt}</p>
                  <div className="mt-4 flex items-center gap-3 font-mono text-[11px] uppercase tracking-widest text-fog">
                    <span>{new Date(p.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                    <span>·</span>
                    <span>{p.readTime}</span>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
