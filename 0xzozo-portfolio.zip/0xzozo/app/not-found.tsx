import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-void px-5 text-center">
      <span className="font-mono text-xs uppercase tracking-[0.3em] text-pulse">
        Error 404
      </span>
      <h1 className="mt-5 font-display text-4xl sm:text-6xl font-medium text-bone">
        This <span className="grad-text">block</span> doesn't exist.
      </h1>
      <p className="mt-4 max-w-md text-sm text-mist">
        The page you're looking for was never mined, or it's moved. Let's get
        you back to the chain.
      </p>
      <Link
        href="/"
        className="mt-8 rounded-full bg-bone px-6 py-3.5 font-mono text-xs uppercase tracking-widest text-void transition-transform hover:-translate-y-0.5"
      >
        Back to Home
      </Link>
    </main>
  );
}
