import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Stats from '@/components/Stats';
import Experience from '@/components/Experience';
import Projects from '@/components/Projects';
import ContentPortfolio from '@/components/ContentPortfolio';
import CaseStudies from '@/components/CaseStudies';
import Skills from '@/components/Skills';
import Services from '@/components/Services';
import Testimonials from '@/components/Testimonials';
import MediaKit from '@/components/MediaKit';
import Collaborations from '@/components/Collaborations';
import BlogPreview from '@/components/BlogPreview';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <main className="relative">
      <Navbar />
      <Hero />
      <About />
      <Stats />
      <Experience />
      <Projects />
      <ContentPortfolio />
      <CaseStudies />
      <Skills />
      <Services />
      <Testimonials />
      <MediaKit />
      <Collaborations />
      <BlogPreview />
      <Contact />
      <Footer />
    </main>
  );
}
