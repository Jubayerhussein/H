# 0xZozo — Web3 Ambassador Portfolio

A premium, dark, glassmorphic Next.js portfolio for a Web3 Ambassador / Content
Creator / Community Builder / Researcher brand.

## Stack

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS
- Framer Motion (animations)
- Lucide Icons

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000. Build for production with `npm run build && npm start`.

## Editing content — no code required

Every section pulls from JSON files in `/data`. Edit the values and the site
updates automatically:

| File | Powers |
|---|---|
| `data/site.json` | Brand name, tagline, hero copy, bio paragraphs, email |
| `data/socials.json` | X, Telegram, Discord, GitHub, LinkedIn, email links |
| `data/stats.json` | Live Statistics cards (add/remove/reorder freely) |
| `data/experience.json` | Ambassador Experience timeline |
| `data/projects.json` | Featured Projects cards |
| `data/caseStudies.json` | Case Studies |
| `data/skills.json` | Skills bars + domain tags |
| `data/services.json` | Services grid |
| `data/testimonials.json` | Testimonial carousel |
| `data/collaborations.json` | Logo carousel |
| `data/blogPosts.json` | Blog cards (home preview + `/blog`) |
| `data/xposts.json` | Embedded X posts — add a `{ "id": "...", "url": "..." }` object to add a new post |
| `data/mediaKit.json` | Download links for resume / portfolio / media kit PDFs |

### Adding real logos and images

Drop image files into `/public/logos`, `/public/blog`, or `/public/media-kit`
and point the relevant JSON field at the path (e.g. `/logos/protocol-alpha.png`).
Placeholder SVGs are included so the site looks complete before you do.

### Media kit files

Place your actual PDF files at:
- `public/media-kit/0xzozo-resume.pdf`
- `public/media-kit/0xzozo-portfolio.pdf`
- `public/media-kit/0xzozo-media-kit.pdf`

(or update the paths in `data/mediaKit.json` to match your filenames).

### Contact form

`components/Contact.tsx` currently simulates a submission. Wire it to a real
endpoint (Formspree, Resend, your own API route) inside the `handleSubmit`
function.

### Open Graph image

Add a 1200×630 image at `public/og-image.png` for rich link previews on X and
elsewhere (referenced in `app/layout.tsx`).

## Design system

- Background: near-black (`#08090B`) with glass panels (`bg-white/[0.03]` +
  blur) — see `.glass` in `app/globals.css`
- Accent gradient: violet `#7C5CFF` → cyan `#00E5C7` (`.grad-text`, glows)
- Type: Space Grotesk (display), Inter (body), JetBrains Mono (labels/data)
- Signature visual: an animated particle "network" canvas in the hero,
  symbolizing connected communities (`components/ParticleField.tsx`)

## SEO

`app/layout.tsx` sets metadata, Open Graph, Twitter Card, and JSON-LD
structured data. `app/sitemap.ts` and `app/robots.ts` generate `/sitemap.xml`
and `/robots.txt` automatically at build time — no manual files needed.

## Notes

- Reduced-motion is respected globally (`prefers-reduced-motion`).
- The custom cursor only activates on non-touch, pointer-capable devices.
- Embedded X posts require an internet connection to load `platform.twitter.com/widgets.js` at runtime.
