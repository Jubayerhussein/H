/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}'
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        void: '#08090B',
        surface: '#0E0F13',
        elevated: '#15171C',
        line: 'rgba(255,255,255,0.08)',
        mist: '#8B8D98',
        fog: '#5A5C66',
        bone: '#EDEDF0',
        signal: {
          DEFAULT: '#7C5CFF',
          soft: '#9B82FF',
          dim: '#4B3B9E'
        },
        pulse: {
          DEFAULT: '#00E5C7',
          soft: '#5FF5DF'
        }
      },
      fontFamily: {
        display: ['var(--font-space-grotesk)', 'sans-serif'],
        body: ['var(--font-inter)', 'sans-serif'],
        mono: ['var(--font-jetbrains)', 'monospace']
      },
      backgroundImage: {
        'grid-fade':
          'linear-gradient(to bottom, rgba(8,9,11,0) 0%, rgba(8,9,11,1) 100%)',
        'radial-glow':
          'radial-gradient(circle at 50% 0%, rgba(124,92,255,0.18), transparent 60%)'
      },
      boxShadow: {
        glow: '0 0 40px -8px rgba(124,92,255,0.5)',
        'glow-cyan': '0 0 40px -8px rgba(0,229,199,0.45)',
        card: '0 8px 30px rgba(0,0,0,0.35)'
      },
      keyframes: {
        float: {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' }
        },
        marquee: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' }
        },
        'pulse-dot': {
          '0%,100%': { opacity: 1, transform: 'scale(1)' },
          '50%': { opacity: 0.5, transform: 'scale(0.8)' }
        }
      },
      animation: {
        float: 'float 6s ease-in-out infinite',
        marquee: 'marquee 30s linear infinite',
        'pulse-dot': 'pulse-dot 2s ease-in-out infinite'
      }
    }
  },
  plugins: []
};
