import { Github, Linkedin, MessageCircle, Send, Twitter } from 'lucide-react';
import site from '@/data/site.json';
import socials from '@/data/socials.json';

const social = [
  { icon: Twitter, href: socials.x, label: 'X' },
  { icon: Send, href: socials.telegram, label: 'Telegram' },
  { icon: MessageCircle, href: socials.discord, label: 'Discord' },
  { icon: Github, href: socials.github, label: 'GitHub' },
  { icon: Linkedin, href: socials.linkedin, label: 'LinkedIn' }
];

const quickLinks = [
  { href: '#about', label: 'About' },
  { href: '#projects', label: 'Projects' },
  { href: '#services', label: 'Services' },
  { href: '#blog', label: 'Blog' },
  { href: '#contact', label: 'Contact' }
];

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-void px-5 py-14 sm:px-8">
      <div className="mx-auto max-w-6xl">
        <div className="flex flex-wrap items-start justify-between gap-10">
          <div>
            <p className="font-display text-lg text-bone">
              0x<span className="grad-text">Zozo</span>
            </p>
            <p className="mt-2 max-w-xs text-sm text-mist">
              {site.tagline}
            </p>
            <div className="mt-5 flex gap-3">
              {social.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.label}
                  className="glass-hover flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-mist hover:text-bone"
                >
                  <s.icon size={15} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <p className="font-mono text-[11px] uppercase tracking-widest text-mist">
              Quick Links
            </p>
            <ul className="mt-3 space-y-2">
              {quickLinks.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-sm text-mist hover:text-bone">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col-reverse items-center justify-between gap-4 border-t border-white/5 pt-6 sm:flex-row">
          <p className="text-xs text-fog">
            © {new Date().getFullYear()} {site.brand}. All rights reserved.
          </p>
          <p className="font-mono text-xs text-fog">{site.domain}</p>
        </div>
      </div>
    </footer>
  );
}
