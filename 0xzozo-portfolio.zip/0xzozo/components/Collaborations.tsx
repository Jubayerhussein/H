import SectionHeading from './SectionHeading';
import collaborations from '@/data/collaborations.json';

export default function Collaborations() {
  const loop = [...collaborations, ...collaborations];

  return (
    <section className="relative border-t border-white/5 bg-surface py-24">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Current Collaborations"
          title="Trusted by teams"
          highlight="building in Web3."
          align="center"
        />
      </div>

      <div className="relative mt-14 overflow-hidden">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-surface to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-surface to-transparent" />
        <div className="marquee-track">
          {loop.map((c, i) => (
            <a
              key={i}
              href={c.url}
              target="_blank"
              rel="noopener noreferrer"
              className="mx-4 flex h-20 w-44 flex-shrink-0 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.03] font-display text-sm text-mist transition-colors hover:border-signal hover:text-bone"
            >
              {c.name}
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
