'use client';

import { motion } from 'framer-motion';
import SectionHeading from './SectionHeading';
import Reveal from './Reveal';
import skills from '@/data/skills.json';

export default function Skills() {
  return (
    <section className="relative border-t border-white/5 bg-surface px-5 py-24 sm:px-8">
      <div className="mx-auto max-w-5xl">
        <SectionHeading eyebrow="Skills" title="Tools of the" highlight="trade." />

        <div className="mt-14 grid gap-14 md:grid-cols-2">
          <div className="space-y-5">
            {skills.core.map((s, i) => (
              <Reveal key={s.name} delay={i * 0.04}>
                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <span className="font-mono text-xs uppercase tracking-widest text-bone">
                      {s.name}
                    </span>
                    <span className="font-mono text-xs text-pulse">{s.level}%</span>
                  </div>
                  <div className="h-[3px] w-full overflow-hidden rounded-full bg-white/10">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${s.level}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.9, ease: 'easeOut' }}
                      className="h-full rounded-full bg-gradient-to-r from-signal to-pulse"
                    />
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.15}>
            <div className="glass rounded-2xl p-8">
              <p className="font-mono text-xs uppercase tracking-widest text-mist">
                Domains
              </p>
              <div className="mt-5 flex flex-wrap gap-3">
                {skills.domains.map((d) => (
                  <span
                    key={d}
                    className="glass-hover rounded-xl border border-white/10 px-4 py-2 font-display text-sm text-bone"
                  >
                    {d}
                  </span>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
