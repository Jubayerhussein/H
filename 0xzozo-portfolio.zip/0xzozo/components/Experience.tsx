import { ArrowUpRight } from 'lucide-react';
import SectionHeading from './SectionHeading';
import Reveal from './Reveal';
import experience from '@/data/experience.json';

export default function Experience() {
  return (
    <section
      id="experience"
      className="relative border-t border-white/5 bg-surface px-5 py-24 sm:px-8"
    >
      <div className="mx-auto max-w-4xl">
        <SectionHeading
          eyebrow="Ambassador Experience"
          title="Where I've"
          highlight="shown up."
          subtitle="A running record of the projects I've represented, and what I actually did for them."
        />

        <div className="relative mt-14 space-y-10 border-l border-white/10 pl-8">
          {experience.map((exp, i) => (
            <Reveal key={exp.id} delay={i * 0.05}>
              <div className="relative">
                <span
                  className={`absolute -left-[38px] top-1.5 h-3 w-3 rounded-full border-2 border-void ${
                    exp.current ? 'bg-pulse shadow-glow-cyan' : 'bg-signal'
                  }`}
                />
                <div className="glass glass-hover rounded-2xl p-6 sm:p-7">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 font-display text-sm text-bone">
                        {exp.project.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-display text-lg text-bone">{exp.project}</p>
                        <p className="font-mono text-[11px] uppercase tracking-widest text-pulse">
                          {exp.role}
                        </p>
                      </div>
                    </div>
                    <span className="font-mono text-[11px] uppercase tracking-widest text-mist">
                      {exp.duration}
                    </span>
                  </div>

                  <ul className="mt-5 space-y-2">
                    {exp.responsibilities.map((r, idx) => (
                      <li key={idx} className="flex gap-2 text-sm leading-relaxed text-mist">
                        <span className="mt-2 h-1 w-1 flex-shrink-0 rounded-full bg-mist/60" />
                        {r}
                      </li>
                    ))}
                  </ul>

                  <div className="mt-5 flex flex-wrap gap-2">
                    {exp.skills.map((s) => (
                      <span
                        key={s}
                        className="rounded-full border border-white/10 px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-mist"
                      >
                        {s}
                      </span>
                    ))}
                  </div>

                  {exp.links?.length > 0 && (
                    <div className="mt-5 flex gap-4">
                      {exp.links.map((l) => (
                        <a
                          key={l.url}
                          href={l.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 font-mono text-[11px] uppercase tracking-widest text-bone hover:text-signal-soft"
                        >
                          {l.label}
                          <ArrowUpRight size={12} />
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
