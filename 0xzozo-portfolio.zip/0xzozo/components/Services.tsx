import SectionHeading from './SectionHeading';
import Reveal from './Reveal';
import services from '@/data/services.json';

export default function Services() {
  return (
    <section id="services" className="relative border-t border-white/5 bg-void px-5 py-24 sm:px-8">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Services"
          title="How I can"
          highlight="help your project."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <Reveal key={s.id} delay={i * 0.04}>
              <div className="glass glass-hover h-full rounded-2xl p-6">
                <span className="font-mono text-xs text-fog">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <p className="mt-3 font-display text-lg text-bone">{s.title}</p>
                <p className="mt-2 text-sm leading-relaxed text-mist">{s.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
