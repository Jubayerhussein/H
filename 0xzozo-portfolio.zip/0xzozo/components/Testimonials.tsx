'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import SectionHeading from './SectionHeading';
import testimonials from '@/data/testimonials.json';

export default function Testimonials() {
  const [index, setIndex] = useState(0);
  const t = testimonials[index];

  function next() {
    setIndex((i) => (i + 1) % testimonials.length);
  }
  function prev() {
    setIndex((i) => (i - 1 + testimonials.length) % testimonials.length);
  }

  return (
    <section className="relative border-t border-white/5 bg-surface px-5 py-24 sm:px-8">
      <div className="mx-auto max-w-3xl text-center">
        <SectionHeading
          eyebrow="Testimonials"
          title="What"
          highlight="teams say."
          align="center"
        />

        <div className="relative mt-14">
          <Quote className="mx-auto mb-6 text-signal" size={28} />
          <AnimatePresence mode="wait">
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.4 }}
              className="glass rounded-2xl p-8 sm:p-10"
            >
              <p className="font-display text-lg sm:text-xl leading-relaxed text-bone">
                "{t.quote}"
              </p>
              <div className="mt-6 flex items-center justify-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/5 font-display text-xs text-bone">
                  {t.name.split(' ').map((n) => n[0]).join('')}
                </div>
                <div className="text-left">
                  <p className="font-mono text-xs uppercase tracking-widest text-bone">
                    {t.name}
                  </p>
                  <p className="text-xs text-mist">{t.title}</p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="mt-6 flex items-center justify-center gap-4">
            <button
              onClick={prev}
              aria-label="Previous testimonial"
              className="glass-hover flex h-10 w-10 items-center justify-center rounded-full border border-white/10"
            >
              <ChevronLeft size={16} className="text-bone" />
            </button>
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  aria-label={`Go to testimonial ${i + 1}`}
                  onClick={() => setIndex(i)}
                  className={`h-1.5 w-1.5 rounded-full transition-colors ${
                    i === index ? 'bg-pulse' : 'bg-white/20'
                  }`}
                />
              ))}
            </div>
            <button
              onClick={next}
              aria-label="Next testimonial"
              className="glass-hover flex h-10 w-10 items-center justify-center rounded-full border border-white/10"
            >
              <ChevronRight size={16} className="text-bone" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
