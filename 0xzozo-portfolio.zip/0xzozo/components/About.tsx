import SectionHeading from './SectionHeading';
import Reveal from './Reveal';
import site from '@/data/site.json';

export default function About() {
  return (
    <section id="about" className="relative border-t border-white/5 bg-surface px-5 py-24 sm:px-8">
      <div className="mx-auto max-w-5xl">
        <SectionHeading
          eyebrow="About"
          title="Built inside Web3,"
          highlight="not adjacent to it."
        />
        <div className="mt-10 grid gap-10 md:grid-cols-2">
          <div className="space-y-5">
            {site.aboutBio.map((p, i) => (
              <Reveal key={i} delay={i * 0.06}>
                <p className="text-sm sm:text-base leading-relaxed text-mist">{p}</p>
              </Reveal>
            ))}
          </div>
          <Reveal delay={0.2}>
            <div className="glass glass-hover rounded-2xl p-8">
              <p className="font-mono text-xs uppercase tracking-widest text-pulse">
                Currently
              </p>
              <p className="mt-3 font-display text-xl text-bone">
                {site.availability}
              </p>
              <div className="mt-6 h-px w-full bg-white/10" />
              <dl className="mt-6 space-y-4 text-sm">
                <div className="flex justify-between">
                  <dt className="text-mist">Based</dt>
                  <dd className="text-bone">{site.location}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-mist">Focus</dt>
                  <dd className="text-bone">DeFi · AI · Gaming · L2</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-mist">Contact</dt>
                  <dd className="text-bone">{site.email}</dd>
                </div>
              </dl>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
