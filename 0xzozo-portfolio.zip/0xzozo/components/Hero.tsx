'use client';

import { motion } from 'framer-motion';
import { ArrowRight, Briefcase, Mail } from 'lucide-react';
import ParticleField from './ParticleField';
import site from '@/data/site.json';

export default function Hero() {
  return (
    <section
      id="top"
      className="relative flex min-h-screen items-center overflow-hidden pt-28 pb-20"
    >
      <div className="absolute inset-0 bg-radial-glow" />
      <ParticleField density={1} />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-void/40 to-void" />

      <div className="relative z-10 mx-auto max-w-5xl px-5 sm:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mx-auto mb-8 flex w-fit items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-pulse shadow-glow-cyan animate-pulse-dot" />
          <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-mist">
            {site.roles.join(' · ')}
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="font-display text-4xl sm:text-6xl md:text-7xl font-medium leading-[1.05] tracking-tight text-bone"
        >
          Helping Web3 Projects{' '}
          <span className="grad-text">Grow</span> Through Content,
          Community, and Strategy.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mx-auto mt-6 max-w-2xl text-sm sm:text-base leading-relaxed text-mist"
        >
          {site.heroIntro}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <a
            href="#projects"
            className="group inline-flex items-center gap-2 rounded-full bg-bone px-6 py-3.5 font-mono text-xs uppercase tracking-widest text-void transition-transform hover:-translate-y-0.5"
          >
            View Portfolio
            <ArrowRight
              size={14}
              className="transition-transform group-hover:translate-x-1"
            />
          </a>
          <a
            href="#services"
            className="inline-flex items-center gap-2 rounded-full border border-white/15 px-6 py-3.5 font-mono text-xs uppercase tracking-widest text-bone transition-colors hover:border-signal hover:text-signal-soft"
          >
            <Briefcase size={14} />
            Hire Me
          </a>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 px-6 py-3.5 font-mono text-xs uppercase tracking-widest text-mist transition-colors hover:text-bone"
          >
            <Mail size={14} />
            Contact
          </a>
        </motion.div>
      </div>
    </section>
  );
}
