import { ArrowUpRight } from 'lucide-react';
import SectionHeading from './SectionHeading';
import Reveal from './Reveal';
import posts from '@/data/blogPosts.json';

export default function BlogPreview() {
  const latest = posts.slice(0, 3);

  return (
    <section id="blog" className="relative border-t border-white/5 bg-void px-5 py-24 sm:px-8">
      <div className="mx-auto max-w-6xl">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading eyebrow="Blog" title="Notes from the" highlight="field." />
          <a
            href="/blog"
            className="inline-flex items-center gap-1 font-mono text-xs uppercase tracking-widest text-bone hover:text-signal-soft"
          >
            View all articles
            <ArrowUpRight size={14} />
          </a>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-3">
          {latest.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.06}>
              <a href={`/blog#${p.slug}`} className="glass glass-hover block h-full rounded-2xl p-6">
                <span className="rounded-full border border-white/10 px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-pulse">
                  {p.category}
                </span>
                <p className="mt-4 font-display text-lg leading-snug text-bone">
                  {p.title}
                </p>
                <p className="mt-2 text-sm leading-relaxed text-mist">{p.excerpt}</p>
                <p className="mt-4 font-mono text-[11px] uppercase tracking-widest text-fog">
                  {p.readTime}
                </p>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
