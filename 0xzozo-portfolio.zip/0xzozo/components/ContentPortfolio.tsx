'use client';

import { useEffect } from 'react';
import SectionHeading from './SectionHeading';
import Reveal from './Reveal';
import xposts from '@/data/xposts.json';

declare global {
  interface Window {
    twttr?: any;
  }
}

export default function ContentPortfolio() {
  useEffect(() => {
    if (document.getElementById('twitter-wjs')) {
      window.twttr?.widgets?.load();
      return;
    }
    const script = document.createElement('script');
    script.id = 'twitter-wjs';
    script.src = 'https://platform.twitter.com/widgets.js';
    script.async = true;
    document.body.appendChild(script);
  }, []);

  return (
    <section className="relative border-t border-white/5 bg-surface px-5 py-24 sm:px-8">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Content Portfolio"
          title="Threads &"
          highlight="posts that landed."
          subtitle="A living grid — add a post to data/xposts.json and it appears here automatically."
        />

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {xposts.map((post) => (
            <Reveal key={post.id}>
              <div className="glass rounded-2xl p-2 [color-scheme:dark]">
                <blockquote className="twitter-tweet" data-theme="dark">
                  <a href={post.url}>Loading post…</a>
                </blockquote>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
