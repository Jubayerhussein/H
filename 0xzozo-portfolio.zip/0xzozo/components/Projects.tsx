import { ArrowUpRight } from 'lucide-react';
import SectionHeading from './SectionHeading';
import Reveal from './Reveal';
import projects from '@/data/projects.json';

export default function Projects() {
  return (
    <section id="projects" className="relative border-t border-white/5 bg-void px-5 py-24 sm:px-8">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Featured Projects"
          title="Work that"
          highlight="speaks for itself."
        />

        <div className="mt-14 grid gap-6 sm:grid-cols-2">
          {projects.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.06}>
              <div className="glass glass-hover flex h-full flex-col rounded-2xl p-7">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/5 font-display text-sm text-bone">
                    {p.name.slice(0, 2).toUpperCase()}
                  </div>
                  <p className="font-display text-lg text-bone">{p.name}</p>
                </div>

                <p className="mt-4 flex-1 text-sm leading-relaxed text-mist">
                  {p.description}
                </p>

                <div className="mt-5 flex flex-wrap gap-2">
                  {p.technology.map((t) => (
                    <span
                      key={t}
                      className="rounded-full border border-white/10 px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-mist"
                    >
                      {t}
                    </span>
                  ))}
                </div>

                <p className="mt-4 text-xs text-pulse">{p.contribution}</p>

                <a
                  href={p.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-6 inline-flex w-fit items-center gap-1 font-mono text-[11px] uppercase tracking-widest text-bone hover:text-signal-soft"
                >
                  Visit Project
                  <ArrowUpRight size={12} />
                </a>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
