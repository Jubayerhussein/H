import { Download, FileText, Folder } from 'lucide-react';
import SectionHeading from './SectionHeading';
import Reveal from './Reveal';
import mediaKit from '@/data/mediaKit.json';

const items = [
  { icon: FileText, label: 'Resume', href: mediaKit.resumeUrl },
  { icon: Folder, label: 'Portfolio PDF', href: mediaKit.portfolioUrl },
  { icon: Download, label: 'Full Media Kit', href: mediaKit.mediaKitUrl }
];

export default function MediaKit() {
  return (
    <section className="relative border-t border-white/5 bg-void px-5 py-24 sm:px-8">
      <div className="mx-auto max-w-4xl">
        <SectionHeading
          eyebrow="Media Kit"
          title="Everything a project"
          highlight="needs, in one place."
          align="center"
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-3">
          {items.map((item, i) => (
            <Reveal key={item.label} delay={i * 0.06}>
              <a
                href={item.href}
                download
                className="glass glass-hover flex flex-col items-center gap-3 rounded-2xl p-8 text-center"
              >
                <item.icon className="text-pulse" size={24} />
                <span className="font-mono text-xs uppercase tracking-widest text-bone">
                  {item.label}
                </span>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
