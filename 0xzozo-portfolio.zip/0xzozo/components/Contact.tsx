'use client';

import { useState, FormEvent } from 'react';
import { Mail, Github, Linkedin, Send, MessageCircle, Twitter } from 'lucide-react';
import SectionHeading from './SectionHeading';
import Reveal from './Reveal';
import socials from '@/data/socials.json';

const channels = [
  { icon: Mail, label: 'Email', value: socials.email, href: `mailto:${socials.email}` },
  { icon: Twitter, label: 'X', value: '@0xZozo', href: socials.x },
  { icon: Send, label: 'Telegram', value: 'Message', href: socials.telegram },
  { icon: MessageCircle, label: 'Discord', value: 'Join', href: socials.discord },
  { icon: Github, label: 'GitHub', value: '@0xZozo', href: socials.github },
  { icon: Linkedin, label: 'LinkedIn', value: 'Connect', href: socials.linkedin }
];

export default function Contact() {
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus('sending');
    // Replace this with your form endpoint (Formspree, Resend, etc.)
    setTimeout(() => setStatus('sent'), 900);
  }

  return (
    <section id="contact" className="relative border-t border-white/5 bg-surface px-5 py-24 sm:px-8">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Contact"
          title="Let's grow your"
          highlight="community together."
        />

        <div className="mt-14 grid gap-8 lg:grid-cols-5">
          <Reveal className="lg:col-span-2">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
              {channels.map((c) => (
                <a
                  key={c.label}
                  href={c.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="glass glass-hover flex items-center gap-3 rounded-xl p-4"
                >
                  <c.icon size={18} className="text-pulse" />
                  <div>
                    <p className="font-mono text-[11px] uppercase tracking-widest text-mist">
                      {c.label}
                    </p>
                    <p className="text-sm text-bone">{c.value}</p>
                  </div>
                </a>
              ))}
            </div>
          </Reveal>

          <Reveal delay={0.1} className="lg:col-span-3">
            <form onSubmit={handleSubmit} className="glass rounded-2xl p-7 sm:p-9">
              <div className="grid gap-5 sm:grid-cols-2">
                <div className="sm:col-span-1">
                  <label className="font-mono text-[11px] uppercase tracking-widest text-mist">
                    Name
                  </label>
                  <input
                    required
                    type="text"
                    name="name"
                    className="mt-2 w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-bone outline-none focus:border-signal"
                    placeholder="Your name"
                  />
                </div>
                <div className="sm:col-span-1">
                  <label className="font-mono text-[11px] uppercase tracking-widest text-mist">
                    Email
                  </label>
                  <input
                    required
                    type="email"
                    name="email"
                    className="mt-2 w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-bone outline-none focus:border-signal"
                    placeholder="you@project.xyz"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="font-mono text-[11px] uppercase tracking-widest text-mist">
                    Project (optional)
                  </label>
                  <input
                    type="text"
                    name="project"
                    className="mt-2 w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-bone outline-none focus:border-signal"
                    placeholder="Project or company name"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="font-mono text-[11px] uppercase tracking-widest text-mist">
                    Message
                  </label>
                  <textarea
                    required
                    name="message"
                    rows={5}
                    className="mt-2 w-full resize-none rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-bone outline-none focus:border-signal"
                    placeholder="Tell me about your project and what you need."
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={status === 'sending'}
                className="mt-6 w-full rounded-full bg-bone py-3.5 font-mono text-xs uppercase tracking-widest text-void transition-transform hover:-translate-y-0.5 disabled:opacity-60 sm:w-auto sm:px-8"
              >
                {status === 'sending'
                  ? 'Sending…'
                  : status === 'sent'
                  ? 'Message sent'
                  : 'Send Message'}
              </button>
              {status === 'sent' && (
                <p className="mt-3 text-xs text-pulse">
                  Thanks — I'll get back to you shortly.
                </p>
              )}
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
