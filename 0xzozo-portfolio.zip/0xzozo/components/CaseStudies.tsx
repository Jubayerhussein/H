import SectionHeading from './SectionHeading';
import Reveal from './Reveal';
import caseStudies from '@/data/caseStudies.json';

const fields: { key: keyof (typeof caseStudies)[number]; label: string }[] = [
  { key: 'challenge', label: 'Challenge' },
  { key: 'strategy', label: 'Strategy' },
  { key: 'contentCreated', label: 'Content Created' },
  { key: 'results', label: 'Results' },
  { key: 'engagement', label: 'Engagement' },
  { key: 'lessonsLearned', label: 'Lessons Learned' }
];

export default function CaseStudies() {
  return (
    <section
      id="case-studies"
      className="relative border-t border-white/5 bg-void px-5 py-24 sm:px-8"
    >
      <div className="mx-auto max-w-5xl">
        <SectionHeading
          eyebrow="Case Studies"
          title="Strategy,"
          highlight="broken down."
        />

        <div className="mt-14 space-y-8">
          {caseStudies.map((cs, i) => (
            <Reveal key={cs.id} delay={i * 0.06}>
              <div className="glass glass-hover rounded-2xl p-7 sm:p-9">
                <p className="font-display text-xl sm:text-2xl text-bone">{cs.project}</p>
                <div className="mt-6 grid gap-6 sm:grid-cols-2">
                  {fields.map((f) => (
                    <div key={String(f.key)}>
                      <p className="font-mono text-[11px] uppercase tracking-widest text-pulse">
                        {f.label}
                      </p>
                      <p className="mt-2 text-sm leading-relaxed text-mist">
                        {cs[f.key]}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
