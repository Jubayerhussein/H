import Reveal from './Reveal';

export default function SectionHeading({
  eyebrow,
  title,
  highlight,
  subtitle,
  align = 'left'
}: {
  eyebrow: string;
  title: string;
  highlight?: string;
  subtitle?: string;
  align?: 'left' | 'center';
}) {
  return (
    <Reveal className={align === 'center' ? 'text-center mx-auto' : ''}>
      <span className="eyebrow">{eyebrow}</span>
      <h2 className="mt-4 font-display text-3xl sm:text-4xl md:text-5xl font-medium leading-[1.08] tracking-tight text-bone">
        {title} {highlight && <span className="grad-text">{highlight}</span>}
      </h2>
      {subtitle && (
        <p
          className={`mt-4 text-sm sm:text-base text-mist leading-relaxed max-w-xl ${
            align === 'center' ? 'mx-auto' : ''
          }`}
        >
          {subtitle}
        </p>
      )}
    </Reveal>
  );
}
